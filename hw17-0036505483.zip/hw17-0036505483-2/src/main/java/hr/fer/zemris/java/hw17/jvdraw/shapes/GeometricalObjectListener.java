package hr.fer.zemris.java.hw17.jvdraw.shapes;

public interface GeometricalObjectListener {
	public void geometricalObjectChanged(GeometricalObject o);
}