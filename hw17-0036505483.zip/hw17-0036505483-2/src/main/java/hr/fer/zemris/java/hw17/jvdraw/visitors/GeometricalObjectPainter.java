package hr.fer.zemris.java.hw17.jvdraw.visitors;

import java.awt.Graphics;

import hr.fer.zemris.java.hw17.jvdraw.shapes.Circle;
import hr.fer.zemris.java.hw17.jvdraw.shapes.FilledCircle;
import hr.fer.zemris.java.hw17.jvdraw.shapes.Line;

public class GeometricalObjectPainter implements GeometricalObjectVisitor {

	private Graphics g2d;

	public GeometricalObjectPainter(Graphics g2d) {
		this.g2d = g2d;
	}

	@Override
	public void visit(Line line) {
		g2d.setColor(line.getColor());
		g2d.drawLine(line.getStart().x, line.getStart().y, line.getEnd().x, line.getEnd().y);
	}

	@Override
	public void visit(Circle circle) {
		double radius = circle.getCenter().distance(circle.getOther()) * 2;
		g2d.drawOval((int) (circle.getCenter().x - radius / 2), (int) (circle.getCenter().y - radius / 2), (int) radius,
				(int) radius);
	}

	@Override
	public void visit(FilledCircle filledCircle) {
		g2d.setColor(filledCircle.getFillColor());
		double radius = filledCircle.getCenter().distance(filledCircle.getOther()) * 2;
		g2d.fillOval((int) (filledCircle.getCenter().x - radius / 2), (int) (filledCircle.getCenter().y - radius / 2),
				(int) radius, (int) radius);
		g2d.setColor(filledCircle.getOutlineColor());
		g2d.drawOval((int) (filledCircle.getCenter().x - radius / 2), (int) (filledCircle.getCenter().y - radius / 2),
				(int) radius, (int) radius);
	}

}
