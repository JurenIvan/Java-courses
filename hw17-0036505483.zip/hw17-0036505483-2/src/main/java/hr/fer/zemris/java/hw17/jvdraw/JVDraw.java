package hr.fer.zemris.java.hw17.jvdraw;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JToggleButton;
import javax.swing.JToolBar;
import javax.swing.SwingUtilities;

import hr.fer.zemris.java.hw17.jvdraw.colorArea.IColorProvider;
import hr.fer.zemris.java.hw17.jvdraw.colorArea.JColorArea;
import hr.fer.zemris.java.hw17.jvdraw.drawingModel.DrawingModel;
import hr.fer.zemris.java.hw17.jvdraw.drawingModel.DrawingModelImpl;
import hr.fer.zemris.java.hw17.jvdraw.editor.GeometricalObjectEditor;
import hr.fer.zemris.java.hw17.jvdraw.shapes.GeometricalObject;
import hr.fer.zemris.java.hw17.jvdraw.tools.CircleTools;
import hr.fer.zemris.java.hw17.jvdraw.tools.FCircleTools;
import hr.fer.zemris.java.hw17.jvdraw.tools.LineTools;
import hr.fer.zemris.java.hw17.jvdraw.tools.Tool;

public class JVDraw extends JFrame {
	private static final long serialVersionUID = 1L;

	private BottomStatusLabel bsl;
	private IColorProvider fgColorProvider;
	private IColorProvider bgColorProvider;
	private DrawingModel drawingModel;
	private JDrawingCanvas canvas;
	private Tool currStateTool;
	private JList<GeometricalObject> rightList;

	public static void main(String[] args) {
		SwingUtilities.invokeLater(() -> new JVDraw().setVisible(true));
	}

	public JVDraw() {
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		initGUI();
		setMinimumSize(new Dimension(600, 600));
		setLocationRelativeTo(null);

	}

	private void initGUI() {
		drawingModel = new DrawingModelImpl();

		Container cp = getContentPane();
		cp.setLayout(new BorderLayout());

		createJCanvas(cp);
		createToolbar(cp);

		createGeometricalObjectsList(cp);

		bsl = new BottomStatusLabel(fgColorProvider, bgColorProvider);
		cp.add(bsl, BorderLayout.PAGE_END);
		bsl.newColorSelected(null, null, null);
		
		}

	private void createGeometricalObjectsList(Container cp) {

		rightList = new JList<>(new DrawingObjectListModel(drawingModel));
		rightList.setVisible(true);
		JScrollPane scrollRightList = new JScrollPane(rightList);
		cp.add(scrollRightList, BorderLayout.EAST);

		MouseListener mouseListener = new MouseAdapter() {
			@SuppressWarnings("unchecked")
			public void mouseClicked(MouseEvent mouseEvent) {
				JList<GeometricalObject> theList = (JList<GeometricalObject>) mouseEvent.getSource();
				if (mouseEvent.getClickCount() == 2) {
					int index = theList.locationToIndex(mouseEvent.getPoint());
					if (index >= 0) {
						GeometricalObject clicked = theList.getModel().getElementAt(index);
						GeometricalObjectEditor editor = clicked.createGeometricalObjectEditor();
						if (JOptionPane.showConfirmDialog(null, editor, "Editor!",
								JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION) {
							try {
								editor.checkEditing();
								editor.acceptEditing();

								// TODO force an update
								
								// TODO force an update
								
								

							} catch (Exception ex) {
								JOptionPane.showMessageDialog(null, ex.getMessage());
								return;
							}
							JOptionPane.showMessageDialog(null, "Succesfull!");
						}
					}
				}
			}
		};

		KeyListener keyListener = new KeyAdapter() {

			@Override
			public void keyTyped(KeyEvent e) {

				switch (e.getKeyChar()) {
				case '+':
					drawingModel.changeOrder(rightList.getSelectedValue(), -1);
					rightList.setSelectedIndex(rightList.getSelectedIndex() - 1);
					break;
				case '-':
					drawingModel.changeOrder(rightList.getSelectedValue(), 1);
					rightList.setSelectedIndex(rightList.getSelectedIndex() + 1);
					break;
				case KeyEvent.VK_DELETE:
					int selectedIndex = rightList.getSelectedIndex();
					drawingModel.remove(rightList.getSelectedValue());
					rightList.setSelectedIndex(selectedIndex - 1 >= 0 ? selectedIndex - 1 : 0);
					break;
				}

			}

		};

		rightList.addMouseListener(mouseListener);
		rightList.addKeyListener(keyListener);
	}

	private void createToolbar(Container cp) {
		JToolBar tb = new JToolBar();
		cp.add(tb, BorderLayout.PAGE_START);

		fgColorProvider = new JColorArea(Color.BLUE);
		bgColorProvider = new JColorArea(Color.RED);

		tb.add((JColorArea) fgColorProvider);
		tb.addSeparator(new Dimension(5, 0));
		tb.add((JColorArea) bgColorProvider);
		tb.addSeparator(new Dimension(20, 0));
		ButtonGroup group = new ButtonGroup();

		JToggleButton line = new JToggleButton("Line");
		line.setSelected(true);
		JToggleButton circle = new JToggleButton("Circle");
		JToggleButton fCircle = new JToggleButton("Filled Circle");

		group.add(line);
		group.add(circle);
		group.add(fCircle);

		tb.add(line);
		tb.add(circle);
		tb.add(fCircle);

		Tool lineTool = new LineTools(fgColorProvider, drawingModel, canvas);
		Tool circleTool = new CircleTools(fgColorProvider, drawingModel, canvas);
		Tool fCircleTool = new FCircleTools(fgColorProvider, bgColorProvider, drawingModel, canvas);

		line.addActionListener((e) -> currStateTool = lineTool);
		circle.addActionListener((e) -> currStateTool = circleTool);
		fCircle.addActionListener((e) -> currStateTool = fCircleTool);

		line.setSelected(true);
		currStateTool = lineTool;
	}

	private void createJCanvas(Container cp) {
		canvas = new JDrawingCanvas(drawingModel, () -> currStateTool);
		cp.add(canvas);
	}

}
