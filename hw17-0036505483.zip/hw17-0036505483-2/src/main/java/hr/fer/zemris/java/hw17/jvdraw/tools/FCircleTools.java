package hr.fer.zemris.java.hw17.jvdraw.tools;

import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.event.MouseEvent;

import hr.fer.zemris.java.hw17.jvdraw.JDrawingCanvas;
import hr.fer.zemris.java.hw17.jvdraw.colorArea.IColorProvider;
import hr.fer.zemris.java.hw17.jvdraw.drawingModel.DrawingModel;
import hr.fer.zemris.java.hw17.jvdraw.shapes.FilledCircle;

public class FCircleTools implements Tool {

	private IColorProvider bgColorProvider;
	private IColorProvider fgColorProvider;
	private DrawingModel drawingModel;
	private boolean beginCircle = true;
	private Point start;
	private Point mousePoint;
	private JDrawingCanvas canvas;

	public FCircleTools(IColorProvider fgColorProvider, IColorProvider bgColorProvider, DrawingModel drawingModel,
			JDrawingCanvas canvas) {
		this.fgColorProvider = fgColorProvider;
		this.drawingModel = drawingModel;
		this.canvas = canvas;
		this.bgColorProvider = bgColorProvider;
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		if (beginCircle) {
			start = e.getPoint();
			beginCircle = false;
		} else {
			FilledCircle circle = new FilledCircle(start, e.getPoint(), fgColorProvider.getCurrentColor(),
					bgColorProvider.getCurrentColor());
			beginCircle = true;
			drawingModel.add(circle);
		}

	}

	@Override
	public void mouseMoved(MouseEvent e) {
		if (!beginCircle) {
			mousePoint=e.getPoint();
			canvas.repaint();
		}
	}

	@Override
	public void mouseDragged(MouseEvent e) {
	}

	@Override
	public void mousePressed(MouseEvent e) {
	}

	@Override
	public void mouseReleased(MouseEvent e) {
	}

	@Override
	public void paint(Graphics2D g2d) {
		
		g2d.setColor(bgColorProvider.getCurrentColor());
		double radius = start.distance(mousePoint) * 2;
		g2d.fillOval((int) (start.x - radius / 2), (int) (start.y - radius / 2), (int) radius, (int) radius);
		g2d.setColor(fgColorProvider.getCurrentColor());
		g2d.drawOval((int) (start.x - radius / 2), (int) (start.y - radius / 2), (int) radius, (int) radius);
	}
}
