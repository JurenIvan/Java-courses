package coloring.demo;

import marcupic.opjj.statespace.coloring.FillApp;

/**
 * Class containing main method used to demonstrate functionalities of premade
 * Program
 * 
 * @author juren
 *
 */
public class Bojanje1 {

	/**
	 * Main method used to start program.
	 * @param args not used
	 */
	public static void main(String[] args) {
		FillApp.run(FillApp.OWL, null); // ili FillApp.ROSE
	}

}
